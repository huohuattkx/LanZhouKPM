﻿#include "kpm_types.h"
#include <cstring>

namespace kpm {

// .kpm.info
static const ModuleInfo kInfo = {
    "LanZhouKPM",
    "v2026",
    "Proprietary",
    "Lanzhou",
    "owo",
};

const ModuleInfo& module_info() { return kInfo; }

// Export-style symbols matching KPM section roles
extern "C" {

__attribute__((used)) const char kpm_name[] = "LanZhouKPM";
__attribute__((used)) const char kpm_version[] = "v2026";
__attribute__((used)) const char kpm_license[] = "Proprietary";
__attribute__((used)) const char kpm_author[] = "Lanzhou";
__attribute__((used)) const char kpm_description[] = "owo";

// entry pointers (analog of .kpm.init/.kpm.ctl0/.kpm.exit)
int kpm_init(const char* args, void* reserved) {
    return kpm::init_fn(args, reserved);
}

int kpm_ctl(const char* arg, char* out, int out_len) {
    return kpm::ctl_fn(arg, out, out_len);
}

int kpm_exit(void) {
    return kpm::exit_fn();
}

} // extern "C"

} // namespace kpm
