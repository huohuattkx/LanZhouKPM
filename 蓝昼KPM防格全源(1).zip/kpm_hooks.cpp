﻿#include "kpm_types.h"
#include <cstring>
#include <cstdlib>

namespace kpm {

// ---------------------------------------------------------------------------
// path / comm helpers
// ---------------------------------------------------------------------------

static thread_local char g_sim_comm[16] = "shell";

void set_current_comm(const char* comm) {
    std::memset(g_sim_comm, 0, sizeof(g_sim_comm));
    if (comm) {
        std::strncpy(g_sim_comm, comm, sizeof(g_sim_comm) - 1);
    }
}

const char* current_comm() {
    return g_sim_comm;
}

bool path_starts_with(const char* path, const char* prefix) {
    if (!path || !prefix) return false;
    size_t n = std::strlen(prefix);
    return std::strncmp(path, prefix, n) == 0;
}

bool path_contains(const char* path, const char* needle) {
    if (!path || !needle) return false;
    return std::strstr(path, needle) != nullptr;
}

bool copy_user_path(const void* user_ptr, char* out, size_t out_sz) {
    if (!out || out_sz == 0) return false;
    out[0] = 0;
    if (!user_ptr) return false;
    if (!G.kf_cfu) {
        // userspace sim: treat pointer as native C string
        std::strncpy(out, static_cast<const char*>(user_ptr), out_sz - 1);
        out[out_sz - 1] = 0;
        return out[0] != 0;
    }
    unsigned long left = G.kf_cfu(out, user_ptr, out_sz - 1);
    if (left >= out_sz) {
        out[0] = 0;
        return false;
    }
    out[out_sz - 1 - left] = 0;
    // kf_cfu returns bytes NOT copied; success if some data arrived
    return out[0] != 0 || (out_sz - 1 - left) > 0;
}

// is_sys @ 0x35d0
// whitelist: init / ueventd / vold / kwo* / loop* / kdm* / jbd* / rmt_
bool is_sys() {
    char comm[0x10]{};
    if (!G.kf_gtc) {
        // if helper missing: original returns 0 (not sys) after early path;
        // but init warns whitelist disabled. Treat missing as not-whitelisted.
        return false;
    }
    // original: __get_task_comm(buf, 0x10, current)
    G.kf_gtc(comm, sizeof(comm), nullptr);

    // exact: "init"
    if (comm[0]=='i' && comm[1]=='n' && comm[2]=='i' && comm[3]=='t' && comm[4]==0)
        return true;
    // "ueventd"
    if (comm[0]=='u' && comm[1]=='e' && comm[2]=='v' && comm[3]=='e' &&
        comm[4]=='n' && comm[5]=='t' && comm[6]=='d' && comm[7]==0)
        return true;
    // "vold"
    if (comm[0]=='v' && comm[1]=='o' && comm[2]=='l' && comm[3]=='d' && comm[4]==0)
        return true;
    // "kwo..." prefix
    if (comm[0]=='k' && comm[1]=='w' && comm[2]=='o')
        return true;
    // "loop..." prefix
    if (comm[0]=='l' && comm[1]=='o' && comm[2]=='o' && comm[3]=='p')
        return true;
    // "kdm..." prefix
    if (comm[0]=='k' && comm[1]=='d' && comm[2]=='m')
        return true;
    // "jbd..." prefix
    if (comm[0]=='j' && comm[1]=='b' && comm[2]=='d')
        return true;
    // "rmt_" prefix (ccmp chain)
    if (comm[0]=='r' && comm[1]=='m' && comm[2]=='t' && comm[3]=='_')
        return true;
    return false;
}

static void log_block(const char* layer, bool have_comm) {
    if (have_comm && G.kf_gtc) {
        char comm[0x10]{};
        G.kf_gtc(comm, sizeof(comm), nullptr);
        host_printk("[-] KP E [bd] BLOCKED: %s layer=%s\n", comm, layer);
    } else {
        host_printk("[-] KP E [bd] BLOCKED: ? layer=%s\n", layer);
    }
}

static bool armed() {
    return auth_state_ptr != nullptr && G.g_on == 1;
}

void set_adb_alert_from_current() {
    G.g_adb_alert = 1;
    std::memset(G.g_adb_alert_comm, 0, sizeof(G.g_adb_alert_comm));
    if (G.kf_gtc) {
        G.kf_gtc(G.g_adb_alert_comm, sizeof(G.g_adb_alert_comm), nullptr);
    } else {
        std::strncpy(G.g_adb_alert_comm, current_comm(), sizeof(G.g_adb_alert_comm) - 1);
    }
}

// ---------------------------------------------------------------------------
// block_cb @ 0x19c8 — blkdev_open / blkdev_get / blkdev_get_by_dev
// ---------------------------------------------------------------------------
void block_cb(hook_ctx* ctx) {
    if (!auth_state_ptr) return;
    if (G.g_on != 1) return;
    if (is_sys()) return;
    block_ctx(ctx, -1);
    if (G.kf_gtc) {
        char comm[0x10]{};
        G.kf_gtc(comm, sizeof(comm), nullptr);
        host_printk("[-] KP E [bd] BLOCKED: %s layer=blkdev\n", comm);
    } else {
        host_printk("[-] KP E [bd] BLOCKED: ? layer=blkdev\n");
    }
}

// ---------------------------------------------------------------------------
// kmod_cb @ 0x2570 — init_module / finit_module / load_module /
//                    find_module / delete_module
// ---------------------------------------------------------------------------
void kmod_cb(hook_ctx* ctx) {
    if (!auth_state_ptr) return;
    if (G.g_on != 1) return;
    if (is_sys()) return;
    block_ctx(ctx, -1);
    if (G.kf_gtc) {
        char comm[0x10]{};
        G.kf_gtc(comm, sizeof(comm), nullptr);
        host_printk("[-] KP E [bd] BLOCKED: %s layer=kmod\n", comm);
    } else {
        host_printk("[-] KP E [bd] BLOCKED: ? layer=kmod\n");
    }
}

// ---------------------------------------------------------------------------
// boot_cb @ 0x2628 — reboot
// ---------------------------------------------------------------------------
void boot_cb(hook_ctx* ctx) {
    if (!auth_state_ptr) return;
    if (G.g_on != 1) return;
    if (is_sys()) return;
    block_ctx(ctx, -1);
    if (G.kf_gtc) {
        char comm[0x10]{};
        G.kf_gtc(comm, sizeof(comm), nullptr);
        host_printk("[-] KP E [bd] BLOCKED: %s layer=boot\n", comm);
    } else {
        host_printk("[-] KP E [bd] BLOCKED: ? layer=boot\n");
    }
    // if module_protect + adb_alert: extra banner
    if (G.g_module_protect == 1 && G.g_adb_alert) {
        host_printk("[-] KP E [bd] REBOOT BLOCKED: adb_alert by %s\n", G.g_adb_alert_comm);
    }
}

// ---------------------------------------------------------------------------
// kill_cb @ 0x2710 — kill / tkill / tgkill
// block when pid == 1 or pid == -1 AND signal in {9,15,19}
// ---------------------------------------------------------------------------
void kill_cb(hook_ctx* ctx) {
    if (!auth_state_ptr) return;
    if (G.g_on != 1) return;
    if (!ctx || !ctx->args) return;

    int32_t pid = static_cast<int32_t>(ctx->args[0]);
    int32_t sig = static_cast<int32_t>(ctx->args[1]);

    if (!(pid == 1 || pid == -1)) return;
    if (static_cast<uint32_t>(sig) > 0x13) return;

    uint32_t bit = 1u << static_cast<uint32_t>(sig);
    if ((bit & kKillSigMask) == 0) return;
    if (is_sys()) return;

    block_ctx(ctx, -1);
    host_printk("[-] KP E [bd] BLOCKED: kill/tkill(%d,%d)\n", pid, sig);
}

// ---------------------------------------------------------------------------
// all_block @ 0x27e0 — kallsyms_on_each_symbol guard
// blocks when g_on == 0 (standby hard-block) and not unloading
// ret = -0x10
// ---------------------------------------------------------------------------
void all_block(hook_ctx* ctx) {
    // tbnz g_unloading -> return
    if (G.g_unloading) return;
    // only block while NOT authenticated
    if (G.g_on != 0) return;
    if (!ctx) return;
    ctx->skip = 1;
    ctx->ret = -0x10;
    G.g_blocked++;
}

// ---------------------------------------------------------------------------
// truncate_cb @ 0x352c — anti unload via magic length
// ---------------------------------------------------------------------------
void truncate_cb(hook_ctx* ctx) {
    if (G.g_on != 1) return;
    if (is_sys()) return;
    if (!ctx || !ctx->args) return;

    // args layout for truncate(path, length): length at args[1]
    uint64_t len = ctx->args[1];
    if (len != kUnloadMagicA && len != kUnloadMagicB) return;

    block_ctx(ctx, -1);
    host_printk("[-] KP E [bd] BLOCKED: kpm-unload magic=0x%lx\n",
                static_cast<unsigned long>(len));
}

// ---------------------------------------------------------------------------
// kln_cb @ 0x3298 — kallsyms_lookup_name filter
// block lookups for sensitive symbol prefixes while g_on && !unloading
// ret forced to 0 (NULL)
// ---------------------------------------------------------------------------
static bool kln_name_blocked(const char* name) {
    if (!name || !name[0]) return false;

    // "blkdev..."
    if (name[0]=='b' && name[1]=='l' && name[2]=='k' &&
        name[3]=='d' && name[4]=='e' && name[5]=='v')
        return true;

    // "bio..."  (b i o _)  — branch via "bio_"
    if (name[0]=='b' && name[1]=='i' && name[2]=='o' && name[3]=='_')
        return true;

    // "__arm64..."  (__arm46 in charseq; actual compare: __arm then '4''6')
    if (name[0]=='_' && name[1]=='_' && name[2]=='a' &&
        name[3]=='r' && name[4]=='m' && name[5]=='6' && name[6]=='4')
        return true;

    // "kallsyms..."
    if (name[0]=='k' && name[1]=='a' && name[2]=='l' &&
        name[3]=='l' && name[4]=='s' && name[5]=='y' &&
        name[6]=='m' && name[7]=='s')
        return true;

    // "vfs..."
    if (name[0]=='v' && name[1]=='f' && name[2]=='s')
        return true;

    // "submit..."
    if (name[0]=='s' && name[1]=='u' && name[2]=='b' &&
        name[3]=='m' && name[4]=='i' && name[5]=='t')
        return true;

    // "hook..."
    if (name[0]=='h' && name[1]=='o' && name[2]=='o' && name[3]=='k')
        return true;

    // "filp_..."
    if (name[0]=='f' && name[1]=='i' && name[2]=='l' &&
        name[3]=='p' && name[4]=='_')
        return true;

    // "kernel_..."
    if (name[0]=='k' && name[1]=='e' && name[2]=='r' &&
        name[3]=='n' && name[4]=='e' && name[5]=='l' && name[6]=='_')
        return true;

    return false;
}

void kln_cb(hook_ctx* ctx) {
    if (G.g_unloading) return;
    if (G.g_on != 1) return;
    if (!ctx || !ctx->args) return;

    const char* name = reinterpret_cast<const char*>(ctx->args[0]);
    // In kernel, args[0] is the name pointer directly for kln.
    // Some wrap layouts pass name as first arg in args array.
    // Recovered: ldrb from [x8] where x8 = args base — so args points at name bytes
    // when symbol is passed by value-pointer. Handle both:
    if (!name) return;

    // If args itself is the C string (observed: ldrb [x8] first char)
    // try interpret args pointer as string first.
    const char* n1 = reinterpret_cast<const char*>(ctx->args);
    const char* n2 = reinterpret_cast<const char*>(ctx->args[0]);
    const char* use = nullptr;
    if (n1 && n1[0] && kln_name_blocked(n1)) use = n1;
    else if (n2 && n2[0] && kln_name_blocked(n2)) use = n2;
    else return;

    (void)use;
    ctx->skip = 1;
    ctx->ret = 0; // NULL
    G.g_blocked++;
}

// ---------------------------------------------------------------------------
// mp_cb @ 0x2d70 / mp_after_cb @ 0x3238 — mmap side channel
// if g_on and args present and addr/size large and flags bit5 set,
// stash user ptr into g_dump_size; after-cb may copy_from_user 0x80
// ---------------------------------------------------------------------------
void mp_cb(hook_ctx* ctx) {
    if (G.g_on != 1) return;
    if (!ctx || !ctx->args) return;
    // args[1] = length-ish; args[3] byte bit5
    uint64_t v = ctx->args[1];
    if (v < (0x100ULL << 12)) return; // < 1MB page units threshold
    uint8_t flags = static_cast<uint8_t>(ctx->args[3] & 0xff); // recovered: ldrb [args+0x18]
    // In u64 args: args[3] is the 4th slot => offset 0x18
    if ((flags & 0x20) == 0) return;
    G.g_dump_size = v;
}

void mp_after_cb(hook_ctx* ctx) {
    if (G.g_on != 1) return;
    if (!ctx) return;
    // require ret in {-1,0}?  add x1,#1; cmp #2; b.lo skip => ret >= 1 or ret == -1 passes?
    // cmp (ret+1) < 2 => ret in {-1,0} skipped. So only ret >= 1 continues.
    if (ctx->ret + 1 < 2) return;
    if (G.g_dump_size < (0x100ULL << 12)) return;
    if (!G.kf_cfu) return;
    char tmp[0x80]{};
    // original copies from somewhere; keep as no-op side buffer in recon
    G.kf_cfu(tmp, reinterpret_cast<const void*>(static_cast<uintptr_t>(G.g_dump_size)), 0x80);
}

// ---------------------------------------------------------------------------
// Path classification recovered from CHARSEQ:
// ufs: /dev/ufs-bsg, /dev/bsg, /dev/sg, /dev/zero,
//      /proc/sysrq-, /config/usb, /sys/class/android_usb,
//      ...socket/.../prop, /data/adb/kpatch,
//      service.d, post-fs-data.d, modules, _update, /lock
// rm:  service.d, post-fs-data.d, modules, _update, /adb, local/adb
// magisk mkdir: modules/_update, service.d, post-fs-data.d, kpatch
// ---------------------------------------------------------------------------

struct PathHit {
    const char* layer;
    bool is_mod;
};

static bool match_mod_tree(const char* path) {
    return path_contains(path, "service.d") ||
           path_contains(path, "post-fs-data.d") ||
           path_contains(path, "/modules") ||
           path_contains(path, "_update");
}

static PathHit classify_open_path(const char* path) {
    if (!path || path[0] != '/') return {nullptr, false};

    if (path_starts_with(path, "/dev/ufs-bsg")) return {"ufs-bsg", false};
    if (path_starts_with(path, "/dev/bsg"))     return {"bsg", false};
    if (path_starts_with(path, "/dev/sg"))      return {"sg", false};
    if (path_starts_with(path, "/dev/zero"))    return {"zero", false};

    if (path_starts_with(path, "/proc/sysrq-")) return {"sysrq", false};
    if (path_starts_with(path, "/config/usb"))  return {"usb-gadget", false};
    if (path_starts_with(path, "/sys/class/android_usb") ||
        path_contains(path, "android_usb"))     return {"android-usb", false};

    if (path_contains(path, "socket") && path_contains(path, "prop"))
        return {"prop-socket", false};

    if (path_contains(path, "/data/adb/kpatch") || path_contains(path, "/kpatch"))
        return {"kpatch-write", true};

    if (path_contains(path, "service.d"))
        return {"mod-serviced", true};
    if (path_contains(path, "post-fs-data.d"))
        return {"mod-postfs", true};
    if (path_contains(path, "/modules") || path_contains(path, "modules/"))
        return {"mod-modules", true};
    if (path_contains(path, "_update"))
        return {"mod-modules", true};

    // block-open / lock path family (CHARSEQ ends with /lock)
    if (path_contains(path, "/lock") || path_contains(path, "block-open"))
        return {"block-open", false};

    return {nullptr, false};
}

static PathHit classify_rm_path(const char* path) {
    if (!path) return {nullptr, false};
    if (match_mod_tree(path)) return {"mod-rm", true};
    if (path_contains(path, "/data/adb") ||
        path_contains(path, "local/adb") ||
        path_contains(path, "/adb"))
        return {"rm", false};
    return {nullptr, false};
}

static PathHit classify_mkdir_path(const char* path) {
    if (!path) return {nullptr, false};
    if (path_contains(path, "modules") && path_contains(path, "_update"))
        return {"mod-mkdir", true};
    if (path_contains(path, "service.d"))
        return {"mod-serviced-mkdir", true};
    if (path_contains(path, "post-fs-data.d"))
        return {"mod-postfs-mkdir", true};
    if (path_contains(path, "kpatch"))
        return {"magisk-kpatch-mkdir", true};
    return {nullptr, false};
}

// ufs_cb @ 0x1a80 — openat / write_iter / ioctl path filter
void ufs_cb(hook_ctx* ctx) {
    if (G.g_on != 1) return;
    if (is_sys()) return;
    if (!ctx || !ctx->args) return;

    // openat(dfd, filename, flags, mode) — filename typically args[1]
    // write_iter / ioctl may put path differently; try common slots
    char path[0x100]{};
    bool got = false;
    const void* candidates[] = {
        reinterpret_cast<const void*>(ctx->args[1]),
        reinterpret_cast<const void*>(ctx->args[0]),
        reinterpret_cast<const void*>(ctx->args[2]),
    };
    for (auto c : candidates) {
        if (copy_user_path(c, path, sizeof(path))) {
            if (path[0] == '/' || path[0] == '.') { got = true; break; }
        }
    }
    if (!got) return;

    PathHit hit = classify_open_path(path);
    if (!hit.layer) return;

    // module tree paths only enforced when g_module_protect is on
    if (hit.is_mod && G.g_module_protect != 1) {
        // kpatch-write is still blocked even without module protect
        if (std::strcmp(hit.layer, "kpatch-write") != 0)
            return;
    }

    block_ctx(ctx, -1);
    log_block(hit.layer, G.kf_gtc != nullptr);
    if (hit.is_mod) {
        G.g_module_blocked++;
        set_adb_alert_from_current();
    }
}

// rm_cb @ 0x281c — unlinkat / rmdir
void rm_cb(hook_ctx* ctx) {
    if (G.g_on != 1) return;
    if (is_sys()) return;
    if (!ctx || !ctx->args) return;

    char path[0x100]{};
    bool got = false;
    const void* candidates[] = {
        reinterpret_cast<const void*>(ctx->args[1]),
        reinterpret_cast<const void*>(ctx->args[0]),
    };
    for (auto c : candidates) {
        if (copy_user_path(c, path, sizeof(path))) { got = true; break; }
    }
    if (!got) return;

    PathHit hit = classify_rm_path(path);
    if (!hit.layer) return;

    if (hit.is_mod && G.g_module_protect != 1) return;

    block_ctx(ctx, -1);
    log_block(hit.layer, G.kf_gtc != nullptr);
    if (hit.is_mod) {
        G.g_module_blocked++;
        set_adb_alert_from_current();
    }
}

// magisk_cb @ 0x2da8 — mkdirat
void magisk_cb(hook_ctx* ctx) {
    if (G.g_on != 1) return;
    if (is_sys()) return;
    if (!ctx || !ctx->args) return;

    char path[0x100]{};
    bool got = false;
    const void* candidates[] = {
        reinterpret_cast<const void*>(ctx->args[1]),
        reinterpret_cast<const void*>(ctx->args[0]),
    };
    for (auto c : candidates) {
        if (copy_user_path(c, path, sizeof(path))) { got = true; break; }
    }
    if (!got) return;

    PathHit hit = classify_mkdir_path(path);
    if (!hit.layer) return;

    // mkdir protection is active under g_on; module paths also bump protect counters
    block_ctx(ctx, -1);
    log_block(hit.layer, G.kf_gtc != nullptr);
    G.g_module_blocked++;
    set_adb_alert_from_current();
}

// ---------------------------------------------------------------------------
// hook install table (mirrors init_fn order)
// argc values recovered from rodata table + typical sys wrapper arities
// ---------------------------------------------------------------------------
static const HookInstall kHooks[] = {
    // early fp hooks for block devices
    {"blkdev_open",        block_cb,   nullptr,     2, true,  -1},
    {"blkdev_get",         block_cb,   nullptr,     2, true,  -1},
    {"blkdev_get_by_dev",  block_cb,   nullptr,     3, true,  -1},

    {"blkdev_write_iter",  ufs_cb,     nullptr,     2, true,  HK_BLKDEV_WRITE_ITER},
    {"blkdev_ioctl",       ufs_cb,     nullptr,     3, true,  HK_BLKDEV_IOCTL},
    {"__arm64_sys_openat", ufs_cb,     nullptr,     4, false, HK_OPENAT},

    {"__arm64_sys_init_module",  kmod_cb, nullptr, 3, false, HK_INIT_MODULE},
    {"__arm64_sys_finit_module", kmod_cb, nullptr, 3, false, HK_FINIT_MODULE},
    {"load_module",              kmod_cb, nullptr, 3, true,  HK_LOAD_MODULE},
    {"find_module",              kmod_cb, nullptr, 1, true,  HK_FIND_MODULE},
    {"__arm64_sys_delete_module",kmod_cb, nullptr, 2, false, HK_DELETE_MODULE},

    {"__arm64_sys_reboot", boot_cb, nullptr, 4, false, HK_REBOOT},

    {"__arm64_sys_kill",   kill_cb, nullptr, 2, false, HK_KILL},
    {"__arm64_sys_tkill",  kill_cb, nullptr, 2, false, HK_TKILL},
    {"__arm64_sys_tgkill", kill_cb, nullptr, 3, false, HK_TGKILL},

    {"__arm64_sys_unlinkat", rm_cb, nullptr, 3, false, HK_UNLINKAT},
    {"__arm64_sys_rmdir",    rm_cb, nullptr, 1, false, HK_RMDIR},

    {"__arm64_sys_mmap",       mp_cb, mp_after_cb, 6, false, HK_MMAP},
    {"__arm64_sys_mkdirat",    magisk_cb, nullptr, 3, false, HK_MKDIRAT},
    {"__arm64_sys_symlinkat",  mp_cb,     nullptr, 3, false, HK_SYMLINKAT},
    {"__arm64_sys_renameat2",  mp_cb,     nullptr, 5, false, HK_RENAMEAT2},

    {"__arm64_sys_truncate", truncate_cb, nullptr, 2, false, -2},

    {"kallsyms_lookup_name",    kln_cb,    nullptr, 1, false, -3},
    {"kallsyms_on_each_symbol", all_block, nullptr, 2, false, -4},
};

const HookInstall* hook_table(size_t* count) {
    if (count) *count = sizeof(kHooks) / sizeof(kHooks[0]);
    return kHooks;
}

} // namespace kpm
