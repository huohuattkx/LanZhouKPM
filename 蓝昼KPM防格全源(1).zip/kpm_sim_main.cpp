﻿#include "kpm_types.h"
#include <cstdio>
#include <cstring>
#include <string>
#include <unordered_map>
#include <vector>

using namespace kpm;

// ---------------- userspace host stubs ----------------
static std::unordered_map<std::string, void*> g_syms;
static std::unordered_map<void*, hook_cb_t> g_before;
static std::unordered_map<void*, hook_cb_t> g_after;
static const char* g_cmdline =
    "androidboot.serialno=EMULATOR1337 oplusboot.serialno=OPLUSDEMO quiet";

static int stub_printk(const char* fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    int r = vprintf(fmt, ap);
    va_end(ap);
    if (fmt && fmt[0] && fmt[std::strlen(fmt)-1] != '\n') putchar('\n');
    return r;
}

static void* stub_kln(const char* name) {
    if (!name) return nullptr;
    auto it = g_syms.find(name);
    if (it == g_syms.end()) return nullptr;
    return it->second;
}

static unsigned long stub_cfu(void* to, const void* from, unsigned long n) {
    if (!to || !from || n == 0) return n;
    std::memcpy(to, from, n);
    return 0;
}

static char* stub_gtc(char* buf, size_t len, void*) {
    if (!buf || len == 0) return buf;
    std::strncpy(buf, current_comm(), len - 1);
    buf[len - 1] = 0;
    return buf;
}

static unsigned long stub_ctu(void* to, const void* from, unsigned long n) {
    if (!to || !from) return n;
    std::memcpy(to, from, n);
    return 0;
}

static int stub_hook_wrap(void* func, hook_cb_t before, hook_cb_t after, void*, int) {
    if (!func) return -1;
    if (before) g_before[func] = before;
    if (after) g_after[func] = after;
    return 0;
}

static int stub_unwrap(void* func, hook_cb_t) {
    g_before.erase(func);
    g_after.erase(func);
    return 0;
}

void kpm::install_default_host_stubs() {
    API.printk = stub_printk;
    API.kallsyms_lookup_name = stub_kln;
    API.hook_wrap = stub_hook_wrap;
    API.fp_hook_wrap = stub_hook_wrap;
    API.hook_unwrap_remove = stub_unwrap;
    API.compat_copy_to_user = stub_ctu;

    // fake kernel symbols — addresses are opaque tokens
    auto put = [](const char* n, int id) {
        g_syms[n] = reinterpret_cast<void*>(static_cast<uintptr_t>(0x1000 + id * 0x10));
    };
    int id = 1;
    put("sys_call_table", id++);
    g_syms["saved_command_line"] = const_cast<char*>(g_cmdline);
    g_syms["__get_task_comm"] = reinterpret_cast<void*>(+[](char* b, size_t l, void* t) -> char* {
        return stub_gtc(b, l, t);
    });
    // store function pointer objects carefully via static wrappers
    static auto gtc = +[](char* b, size_t l, void* t) -> char* { return stub_gtc(b, l, t); };
    static auto cfu = +[](void* a, const void* b, unsigned long n) -> unsigned long { return stub_cfu(a,b,n); };
    g_syms["__get_task_comm"] = reinterpret_cast<void*>(gtc);
    g_syms["_copy_from_user"] = reinterpret_cast<void*>(cfu);
    g_syms["copy_from_user"] = reinterpret_cast<void*>(cfu);
    g_syms["__arch_copy_from_user"] = reinterpret_cast<void*>(cfu);

    const char* names[] = {
        "blkdev_open","blkdev_get","blkdev_get_by_dev",
        "blkdev_write_iter","blkdev_ioctl","__arm64_sys_openat",
        "__arm64_sys_init_module","__arm64_sys_finit_module","load_module",
        "find_module","__arm64_sys_delete_module","__arm64_sys_reboot",
        "__arm64_sys_kill","__arm64_sys_tkill","__arm64_sys_tgkill",
        "__arm64_sys_unlinkat","__arm64_sys_rmdir","__arm64_sys_mmap",
        "__arm64_sys_mkdirat","__arm64_sys_symlinkat","__arm64_sys_renameat2",
        "__arm64_sys_truncate","kallsyms_lookup_name","kallsyms_on_each_symbol",
    };
    for (const char* n : names) put(n, id++);
}

// invoke installed before-hook by symbol name
static void fire(const char* sym, hook_ctx* ctx) {
    void* fn = stub_kln(sym);
    auto it = g_before.find(fn);
    if (it != g_before.end() && it->second) it->second(ctx);
}

static void banner(const char* s) {
    printf("\n==== %s ====\n", s);
}

int main() {
    install_default_host_stubs();

    banner("init_fn");
    int irc = init_fn(nullptr, nullptr);
    printf("init_fn => %d\n", irc);

    char out[64]{};

    banner("status before auth");
    ctl_fn("S", out, sizeof(out));
    printf("reply=[%s] g_on=%u\n", out, G.g_on);

    banner("bad token");
    ctl_fn("AAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA", out, sizeof(out));

    banner("auth token (_ak)");
    char token[33]{};
    make_token_from_key(kAuthKey, token);
    std::memset(out, 0, sizeof(out));
    ctl_fn(token, out, sizeof(out));
    printf("reply=[%s] g_on=%u auth.state=%llu\n", out, G.g_on,
           static_cast<unsigned long long>(G.auth.state));

    banner("module protect ON");
    ctl_fn("M:1", out, sizeof(out));

    banner("hook: openat /dev/ufs-bsg");
    set_current_comm("adb");
    const char* path = "/dev/ufs-bsg0";
    uint64_t args_open[4] = {
        static_cast<uint64_t>(-100), // AT_FDCWD
        reinterpret_cast<uint64_t>(path),
        0, 0
    };
    hook_ctx ctx{};
    ctx.args = args_open;
    fire("__arm64_sys_openat", &ctx);
    printf("skip=%u ret=%lld blocked=%llu\n", ctx.skip,
           static_cast<long long>(ctx.ret),
           static_cast<unsigned long long>(G.g_blocked));

    banner("hook: openat whitelisted init");
    set_current_comm("init");
    ctx = {};
    ctx.args = args_open;
    fire("__arm64_sys_openat", &ctx);
    printf("skip=%u (expect 0) blocked=%llu\n", ctx.skip,
           static_cast<unsigned long long>(G.g_blocked));

    banner("hook: mkdir modules/_update");
    set_current_comm("magisk");
    const char* mp = "/data/adb/modules/_update";
    uint64_t args_mkdir[3] = {
        static_cast<uint64_t>(-100),
        reinterpret_cast<uint64_t>(mp),
        0755
    };
    ctx = {};
    ctx.args = args_mkdir;
    fire("__arm64_sys_mkdirat", &ctx);
    printf("skip=%u layer expect mod-mkdir alert=%u comm=%s\n",
           ctx.skip, G.g_adb_alert, G.g_adb_alert_comm);

    banner("hook: kill pid1 SIGKILL");
    set_current_comm("shell");
    uint64_t args_kill[2] = {1, 9};
    ctx = {};
    ctx.args = args_kill;
    fire("__arm64_sys_kill", &ctx);
    printf("skip=%u ret=%lld\n", ctx.skip, static_cast<long long>(ctx.ret));

    banner("hook: truncate unload magic");
    uint64_t args_tr[2] = {0, kUnloadMagicA};
    ctx = {};
    ctx.args = args_tr;
    fire("__arm64_sys_truncate", &ctx);
    printf("skip=%u\n", ctx.skip);

    banner("hook: kmod");
    ctx = {};
    uint64_t args0[3] = {0,0,0};
    ctx.args = args0;
    fire("__arm64_sys_init_module", &ctx);
    printf("skip=%u\n", ctx.skip);

    banner("challenge auth path");
    // re-init flags for demo of FC without clearing hooks
    G.g_on = 0;
    G.auth.state = 0;
    ctl_fn("C:123456789", out, sizeof(out));
    ctl_fn("FC:123456789", out, sizeof(out));
    printf("after FC g_on=%u reply=[%s]\n", G.g_on, out);

    banner("unlock then exit");
    char uk[33]{};
    make_token_from_key(kUnlockKey, uk);
    ctl_fn(uk, out, sizeof(out));
    printf("unlock reply=[%s] unlock_ok=%u\n", out, G.g_unlock_ok);
    int erc = exit_fn();
    printf("exit_fn => %d\n", erc);

    banner("exit without unlock should fail");
    G.g_unlock_ok = 0;
    erc = exit_fn();
    printf("exit_fn => %d (expect -1)\n", erc);

    banner("token dump (lab)");
    printf("auth_token  = [%s]\n", token);
    printf("unlock_token= [%s]\n", uk);
    printf("done.\n");
    return 0;
}
