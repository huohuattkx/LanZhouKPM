﻿# LanZhouKPM Hook Logic Reconstruction

Target: `E:\apk_analysis\embedded_kpm.elf` (from APK, AArch64 ET_REL KPM)
Module: **LanZhouKPM** `v2026` / author **Lanzhou**

## Answer to difficulty question

| 项 | 结论 |
|----|------|
| 卡密验证 | **更简单**。落在 userspace SO/JNI 协议层，已有 emulator 链路时可直接 hook/patch 决策点或重放 token。 |
| KPM 还原 | **更难**。内核模块 ET_REL + XOR 串 + 大量路径 char-compare + ctl 多命令 + 反卸载，需要完整静态还原。 |

当前交付以 **KPM hook 逻辑完整 C++ 还原** 为主（卡密线已完成，不再展开）。

## Layout

```
kpm_reconstruct/
  kpm_types.h        # ctx/globals/keys/API
  kpm_hooks.cpp      # is_sys + all callbacks + path classifiers + install table
  kpm_init.cpp       # init_fn / exit_fn
  kpm_ctl.cpp        # ctl_fn commands + XOR shared-secret auth
  kpm_module.cpp     # .kpm.info metadata + C exports
  kpm_sim_main.cpp   # userspace host stubs + behavior smoke test
  README.md
```

## Recovered architecture

```
init_fn
  resolve sys_call_table / saved_command_line / helpers
  install hooks (standby, g_on=0)
  print: loaded (standby) + await auth

ctl_fn
  S | C:<n> | FC:<n> | A:Q/A:R | M:0/1/Q | 32B secret
  secret: (arg[i]^0x9f) == _ak[i]  -> auth, g_on=1
          (arg[i]^0x9f) == _uk[i]  -> unlock_ok=1 (allow unload)
  FC challenge success -> same as auth

callbacks (only enforce when g_on==1, except all_block)
  block_cb / ufs_cb / kmod_cb / boot_cb / kill_cb /
  rm_cb / magisk_cb / truncate_cb / kln_cb / mp_cb
  all_block: hard-block kallsyms_on_each while g_on==0

exit_fn
  require g_unlock_ok else anti-tamper reject
  unwrap hooks, g_on=0
```

## Hook map (role → callback → symbols)

| Role | Callback | Symbols |
|------|----------|---------|
| block device open | `block_cb` | `blkdev_open`, `blkdev_get`, `blkdev_get_by_dev` |
| path open/write/ioctl | `ufs_cb` | `blkdev_write_iter`, `blkdev_ioctl`, `__arm64_sys_openat` |
| module load/unload | `kmod_cb` | `init_module`, `finit_module`, `load_module`, `find_module`, `delete_module` |
| reboot | `boot_cb` | `__arm64_sys_reboot` |
| kill pid1/-1 | `kill_cb` | `kill`, `tkill`, `tgkill` |
| unlink/rmdir | `rm_cb` | `unlinkat`, `rmdir` |
| mkdir magisk tree | `magisk_cb` | `mkdirat` |
| mmap side | `mp_cb`/`mp_after_cb` | `mmap`, `symlinkat`, `renameat2` |
| unload magic | `truncate_cb` | `truncate` |
| kln filter | `kln_cb` | `kallsyms_lookup_name` |
| pre-auth hard block | `all_block` | `kallsyms_on_each_symbol` |

## Path layers (`ufs_cb` / `rm_cb` / `magisk_cb`)

From recovered CHARSEQ (not rodata strings):

- `/dev/ufs-bsg`, `/dev/bsg`, `/dev/sg`, `/dev/zero`
- `/proc/sysrq-`
- `/config/usb` (usb-gadget)
- `/sys/class/android_usb`
- `socket` + `prop`
- `/data/adb/kpatch`
- Magisk: `service.d`, `post-fs-data.d`, `modules`, `_update`
- rm also: `/data/adb`, `local/adb`
- mkdir: `modules/_update`, `service.d`, `post-fs-data.d`, `kpatch`

## Auth material

- XOR key: `0x9F`
- `_ak` / `_uk` in `.rodata.cst32` (32B each), `ak[i]^uk[i]==0x01`
- unload magics: `0x0d0520261021`, `0x0d0520261008`
- kill mask: signals `{9,15,19}` via `0x88200`

Generate lab tokens:

```cpp
char tok[33];
make_token_from_key(kAuthKey, tok);   // auth
make_token_from_key(kUnlockKey, tok); // unlock
```

## is_sys whitelist

`init`, `ueventd`, `vold`, `kwo*`, `loop*`, `kdm*`, `jbd*`, `rmt_`

## Build / run (userspace sim)

```powershell
cd E:\apk_analysis\kpm_reconstruct
# MSVC
cl /std:c++17 /EHsc /Fe:kpm_sim.exe kpm_hooks.cpp kpm_init.cpp kpm_ctl.cpp kpm_module.cpp kpm_sim_main.cpp
.\kpm_sim.exe

# or clang/g++
clang++ -std=c++17 -O2 -o kpm_sim.exe kpm_hooks.cpp kpm_init.cpp kpm_ctl.cpp kpm_module.cpp kpm_sim_main.cpp
```

## Evidence anchors

| Item | Evidence |
|------|----------|
| entries | rela: init@0x6c ctl@0xb60 exit@0x1568 |
| XOR banners | `_xs_*` key 0x9f in `kpm_logic_map.txt` |
| keys | `.rodata.cst32` dump |
| callbacks | `kpm_detail4_out.txt` / `kpm_detail2.txt` |
| path CHARSEQ | `kpm_detail2.txt` FUNC ufs/rm/magisk |
| ctl dispatch | `kpm_detail3_out.txt` |

## Notes / fidelity limits

1. KernelPatch `hook_ctx` field layout recovered from store offsets (`+8`,`+0x50`,`+0x58`); other pad fields unused.
2. Some openat/ioctl argument slot selection is multi-candidate (args[0..2]) for sim robustness; kernel path uses the real wrap ABI.
3. `mp_cb`/`mp_after_cb` side-buffer behavior is partially opaque; reconstructed as size/flag gate + optional `copy_from_user`.
4. `kln_cb` name matching reconstructed from char-compare tree (blkdev/bio/__arm64/kallsyms/vfs/submit/hook/filp_/kernel_).
5. This is a **logic-accurate userspace reconstruction**, not a loadable KPM binary.
