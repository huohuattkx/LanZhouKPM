﻿#include "kpm_types.h"
#include <cstring>
#include <cstdlib>
#include <cstdio>

namespace kpm {

bool match_secret_32(const char* arg, const uint8_t key[32]) {
    if (!arg) return false;
    for (int i = 0; i < 32; ++i) {
        unsigned char c = static_cast<unsigned char>(arg[i]);
        if (c == 0) return false;
        if (static_cast<uint8_t>(c ^ kXorKey) != key[i]) return false;
    }
    // exact 32 bytes, no trailing junk
    return arg[32] == 0;
}

void make_token_from_key(const uint8_t key[32], char out[33]) {
    for (int i = 0; i < 32; ++i) {
        out[i] = static_cast<char>(key[i] ^ kXorKey);
    }
    out[32] = 0;
}

void do_auth_success() {
    host_printk("[+] KP I %s\n", XS_AUTH_OK);
    if (G.g_on == 0) {
        // write auth state (non-zero) into .kpm.auth+16
        G.auth.state = 1;
        G.g_on = 1;
        host_printk("[+] KP I [bd] protection ON (authenticated, blocked=%lu)\n",
                    static_cast<unsigned long>(G.g_blocked));
    }
}

static int copy_reply(char* out_buf, int out_len, const char* s) {
    if (!out_buf || out_len <= 0 || !s) return 0;
    int n = static_cast<int>(std::strlen(s));
    if (n + 1 > out_len) n = out_len - 1;
    if (n < 0) return 0;
    if (API.compat_copy_to_user) {
        API.compat_copy_to_user(out_buf, s, static_cast<unsigned long>(n + 1));
    } else {
        std::memcpy(out_buf, s, static_cast<size_t>(n));
        out_buf[n] = 0;
    }
    return n;
}

// parse decimal after prefix; returns true if consumed clean number
static bool parse_u64_tail(const char* p, uint64_t* out) {
    if (!p || !*p || !out) return false;
    char* end = nullptr;
    unsigned long long v = std::strtoull(p, &end, 10);
    if (end == p) return false;
    // allow trailing \n or NUL
    if (*end != 0 && *end != '\n' && *end != '\r') return false;
    *out = static_cast<uint64_t>(v);
    return true;
}

// ctl_fn @ 0xb60
// Commands:
//   S            status -> "on"/"off" (+ blocked formatting path)
//   C:<u64>      challenge set
//   FC:<u64>     finish challenge (must match g_chal_val)
//   A:Q / A:R    adb alert query / reset
//   M:1 / M:0 / M:Q  module protect on/off/query
//   <32B secret> auth (_ak) or unlock (_uk)
int ctl_fn(const char* arg, char* out_buf, int out_len) {
    if (!arg) {
        // empty -> status-like path when out provided
        if (out_buf && out_len >= 4) {
            return copy_reply(out_buf, out_len, G.g_on ? "on" : "off");
        }
        return 0;
    }

    unsigned char c0 = static_cast<unsigned char>(arg[0]);

    // ---- S / S\n status ----
    if (c0 == 'S' && (arg[1] == 0 || arg[1] == '\n')) {
        // original builds a small status buffer; for recon expose on/off
        // and blocked count via printk when useful.
        if (out_buf && out_len >= 4) {
            copy_reply(out_buf, out_len, G.g_on ? "on" : "off");
        }
        host_printk("[+] KP I status on=%u blocked=%lu mprotect=%u mblocked=%lu unlock=%u\n",
                    G.g_on,
                    static_cast<unsigned long>(G.g_blocked),
                    G.g_module_protect,
                    static_cast<unsigned long>(G.g_module_blocked),
                    G.g_unlock_ok);
        return 0;
    }

    // ---- C:<val> challenge ----
    if (c0 == 'C' && arg[1] == ':') {
        uint64_t v = 0;
        if (!parse_u64_tail(arg + 2, &v)) {
            // fallthrough to secret path if not a clean number
        } else {
            G.g_chal_val = v;
            G.g_chal_ok = 1;
            if (out_buf && out_len >= 3) copy_reply(out_buf, out_len, "ok");
            return 0;
        }
    }

    // ---- FC:<val> finish challenge ----
    if (c0 == 'F' && arg[1] == 'C' && arg[2] == ':') {
        if (!G.g_chal_ok) {
            host_printk("[-] KP E %s\n", XS_UNAUTH);
            return -1;
        }
        G.g_chal_ok = 0;
        uint64_t v = 0;
        if (!parse_u64_tail(arg + 3, &v) || v != G.g_chal_val) {
            host_printk("[-] KP E %s\n", XS_UNAUTH);
            return -1;
        }
        do_auth_success();
        if (out_buf && out_len >= 3) copy_reply(out_buf, out_len, "on");
        return 0;
    }

    // ---- A:Q / A:R ----
    if (c0 == 'A' && arg[1] == ':') {
        char sub = arg[2];
        if (sub == 'R') {
            G.g_adb_alert = 0;
            std::memset(G.g_adb_alert_comm, 0, sizeof(G.g_adb_alert_comm));
            if (out_buf && out_len >= 3) copy_reply(out_buf, out_len, "ok");
            return 0;
        }
        if (sub == 'Q') {
            if (G.g_adb_alert && G.g_adb_alert_comm[0]) {
                if (out_buf && out_len > 1) {
                    copy_reply(out_buf, out_len, G.g_adb_alert_comm);
                }
            } else {
                if (out_buf && out_len >= 3) copy_reply(out_buf, out_len, "ok");
            }
            return 0;
        }
        // unknown A: fallthrough
    }

    // ---- M:0 / M:1 / M:Q ----
    if (c0 == 'M' && arg[1] == ':') {
        char sub = arg[2];
        if (sub == '1') {
            G.g_module_protect = 1;
            host_printk("[+] KP I [bd] module protect ON\n");
            if (out_buf && out_len >= 3) copy_reply(out_buf, out_len, "ok");
            return 0;
        }
        if (sub == '0') {
            G.g_module_protect = 0;
            host_printk("[+] KP I [bd] module protect OFF\n");
            if (out_buf && out_len >= 3) copy_reply(out_buf, out_len, "ok");
            return 0;
        }
        if (sub == 'Q') {
            // query counters — return compact text
            char tmp[64];
            std::snprintf(tmp, sizeof(tmp), "%u:%lu",
                          G.g_module_protect,
                          static_cast<unsigned long>(G.g_module_blocked));
            if (out_buf && out_len > 1) copy_reply(out_buf, out_len, tmp);
            return 0;
        }
        // unknown M: fallthrough
    }

    // ---- 32-byte shared secret token ----
    // compare (arg[i]^0x9f) against _uk and _ak in parallel
    bool match_uk = true;
    bool match_ak = true;
    for (int i = 0; i < 32; ++i) {
        unsigned char c = static_cast<unsigned char>(arg[i]);
        if (c == 0) {
            match_uk = match_ak = false;
            break;
        }
        uint8_t x = static_cast<uint8_t>(c ^ kXorKey);
        if (x != kUnlockKey[i]) match_uk = false;
        if (x != kAuthKey[i]) match_ak = false;
    }
    if (arg[0] && arg[32] != 0) {
        match_uk = match_ak = false;
    }

    if (match_uk) {
        G.g_unlock_ok = 1;
        // stack string " [bd] anti-lock disabled" recovered as movk sequence:
        // prints via "[+] KP I %s" with local banner; keep concise
        host_printk("[+] KP I [bd] anti-lock disabled\n");
        if (out_buf && out_len >= 8) copy_reply(out_buf, out_len, "unlock");
        return 0;
    }

    if (match_ak) {
        do_auth_success();
        if (out_buf && out_len >= 3) copy_reply(out_buf, out_len, "on");
        return 0;
    }

    // unauthorized
    host_printk("[-] KP E %s\n", XS_UNAUTH);
    return -1;
}

} // namespace kpm
