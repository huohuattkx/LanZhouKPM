﻿#pragma once

#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdio>
#include <cstdarg>
#include <string>
#include <algorithm>

// LanZhouKPM v2026 — static reconstruction of embedded_kpm.elf (AArch64 ET_REL)
// Evidence: kpm_detail2/3/4, kpm_full_critical, kpm_logic_map, rela/strings.

namespace kpm {

// KernelPatch wrap context (recovered from callbacks)
// ctx+0x08 = skip/block flag (1 = do not call original)
// ctx+0x50 = forced return value
// ctx+0x58 = pointer to argument array (u64 slots)
struct hook_ctx {
    uint64_t reserved0;   // +0x00
    uint32_t skip;        // +0x08  1 = blocked
    uint32_t pad0c;
    uint64_t pad10[7];    // +0x10 .. +0x48
    int64_t  ret;         // +0x50
    uint64_t* args;       // +0x58
};

using hook_cb_t = void (*)(hook_ctx* ctx);
using kln_fn_t = void* (*)(const char* name);
using printk_fn_t = int (*)(const char* fmt, ...);
using copy_from_user_fn_t = unsigned long (*)(void* to, const void* from, unsigned long n);
using get_task_comm_fn_t = char* (*)(char* buf, size_t len, void* task);
using hook_wrap_fn_t = int (*)(void* func, hook_cb_t before, hook_cb_t after, void* udata, int argc);
using fp_hook_wrap_fn_t = int (*)(void* func, hook_cb_t before, hook_cb_t after, void* udata, int argc);
using hook_unwrap_fn_t = int (*)(void* func, hook_cb_t before);
using copy_to_user_fn_t = unsigned long (*)(void* to, const void* from, unsigned long n);

struct host_api {
    kln_fn_t              kallsyms_lookup_name = nullptr;
    printk_fn_t           printk = nullptr;
    fp_hook_wrap_fn_t     fp_hook_wrap = nullptr;
    hook_wrap_fn_t        hook_wrap = nullptr;
    hook_unwrap_fn_t      hook_unwrap_remove = nullptr;
    copy_to_user_fn_t     compat_copy_to_user = nullptr;
};

// Shared-secret material (.rodata.cst32)
// Token check: for i in 0..31: (arg[i] ^ 0x9F) == key[i]; arg[32] must be 0.
inline constexpr uint8_t kXorKey = 0x9f;

inline constexpr uint8_t kAuthKey[32] = {
    0xc8, 0xde, 0xef, 0xd6, 0xd1, 0xf5, 0xd6, 0xcd,
    0xda, 0xa9, 0xac, 0xd7, 0xf8, 0xeb, 0xe7, 0xd4,
    0xec, 0xca, 0xee, 0xe9, 0xac, 0xf2, 0xf1, 0xe8,
    0xfa, 0xfb, 0xfc, 0xd8, 0xae, 0xdc, 0xef, 0xe7,
};

inline constexpr uint8_t kUnlockKey[32] = {
    0xc9, 0xdf, 0xee, 0xd7, 0xd0, 0xf4, 0xd7, 0xcc,
    0xdb, 0xa8, 0xad, 0xd6, 0xf9, 0xea, 0xe6, 0xd5,
    0xed, 0xcb, 0xef, 0xe8, 0xad, 0xf3, 0xf0, 0xe9,
    0xfb, 0xfa, 0xfd, 0xd9, 0xaf, 0xdd, 0xee, 0xe6,
};

inline constexpr uint64_t kUnloadMagicA = 0x0d0520261021ULL;
inline constexpr uint64_t kUnloadMagicB = 0x0d0520261008ULL;

// SIGKILL(9)|SIGTERM(15)|SIGSTOP(19) => 0x8200 | (8<<16) = 0x88200
inline constexpr uint32_t kKillSigMask = 0x00088200u;

struct AuthSection {
    char     marker_ampk[8];   // "AMPK"
    uint64_t hash;
    uint64_t state;            // written non-zero on successful auth
    uint64_t code_hash;
    char     marker_empk[8];   // "EMPK"
    char     marker_smpk[8];   // "SMPK"
    uint32_t auth_list[128];   // {id, 0xdead} pairs
};

struct ModuleInfo {
    const char* name;
    const char* version;
    const char* license;
    const char* author;
    const char* description;
};

enum HookSlot : int {
    HK_BLKDEV_WRITE_ITER = 0,
    HK_BLKDEV_IOCTL,
    HK_OPENAT,
    HK_INIT_MODULE,
    HK_FINIT_MODULE,
    HK_REBOOT,
    HK_KILL,
    HK_TKILL,
    HK_TGKILL,
    HK_LOAD_MODULE,
    HK_FIND_MODULE,
    HK_DELETE_MODULE,
    HK_UNLINKAT,
    HK_RMDIR,
    HK_MMAP,
    HK_MKDIRAT,
    HK_SYMLINKAT,
    HK_RENAMEAT2,
    HK_COUNT
};

struct HookInstall {
    const char* symbol;
    hook_cb_t   before;
    hook_cb_t   after;
    int         argc;
    bool        use_fp_hook;
    int         slot; // g_hk index, or -1 special
};

struct Globals {
    void*    g_sct = nullptr;
    char     g_device_id[0x100]{};
    int      _init_done = 0;

    get_task_comm_fn_t  kf_gtc = nullptr;
    copy_from_user_fn_t kf_cfu = nullptr;

    void*    g_hk[HK_COUNT]{};
    int      g_hk_argc[HK_COUNT]{};
    void*    g_hk_trunc = nullptr;
    void*    g_hk_uwrap = nullptr;
    void*    g_hk_kaes = nullptr;
    void*    g_fp_trunc = nullptr;
    void*    g_fp[HK_COUNT]{};

    uint8_t  g_unloading = 0;
    uint8_t  g_on = 0;
    uint64_t g_blocked = 0;
    uint8_t  g_module_protect = 0;
    uint64_t g_module_blocked = 0;
    uint8_t  g_adb_alert = 0;
    char     g_adb_alert_comm[0x10]{};
    uint64_t g_dump_size = 0;
    uint64_t g_chal_val = 0;
    uint8_t  g_chal_ok = 0;
    uint8_t  g_unlock_ok = 0;

    void*    g_blkdev_open = nullptr;
    void*    g_blkdev_get = nullptr;
    void*    g_blkdev_get_by_dev = nullptr;
    void*    g_kln = nullptr;
    void*    g_kallsyms_on_each = nullptr;

    AuthSection auth{};
};

inline Globals G;
inline host_api API;
inline AuthSection* auth_state_ptr = &G.auth;

inline constexpr const char* XS_LOADED   = "[bd] v6.0 loaded, hooks installed (standby)";
inline constexpr const char* XS_AWAIT    = "[bd] await authenticated activation";
inline constexpr const char* XS_AUTH_OK  = "[bd] authenticated via shared secret";
inline constexpr const char* XS_UNAUTH   = "[bd] unauthorized access attempt";
inline constexpr const char* XS_UNLOAD_R = "[bd] unload rejected (anti-tamper)";

inline void block_ctx(hook_ctx* ctx, int64_t ret = -1) {
    if (!ctx) return;
    ctx->skip = 1;
    ctx->ret = ret;
    G.g_blocked++;
}

inline void block_ctx_eperm(hook_ctx* ctx) {
    block_ctx(ctx, -0x10);
}

inline int host_printk(const char* fmt, ...) {
    char buf[512];
    va_list ap;
    va_start(ap, fmt);
    vsnprintf(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    if (API.printk) return API.printk("%s", buf);
    fputs(buf, stdout);
    if (buf[0] && buf[std::strlen(buf) - 1] != '\n') fputc('\n', stdout);
    return 0;
}

bool is_sys();
void block_cb(hook_ctx* ctx);
void ufs_cb(hook_ctx* ctx);
void kmod_cb(hook_ctx* ctx);
void boot_cb(hook_ctx* ctx);
void kill_cb(hook_ctx* ctx);
void all_block(hook_ctx* ctx);
void rm_cb(hook_ctx* ctx);
void magisk_cb(hook_ctx* ctx);
void mp_cb(hook_ctx* ctx);
void mp_after_cb(hook_ctx* ctx);
void kln_cb(hook_ctx* ctx);
void truncate_cb(hook_ctx* ctx);

int  init_fn(const char* args, void* reserved);
int  ctl_fn(const char* arg, char* out_buf, int out_len);
int  exit_fn();

bool path_starts_with(const char* path, const char* prefix);
bool path_contains(const char* path, const char* needle);
bool copy_user_path(const void* user_ptr, char* out, size_t out_sz);
bool match_secret_32(const char* arg, const uint8_t key[32]);
void make_token_from_key(const uint8_t key[32], char out[33]);
const HookInstall* hook_table(size_t* count);
void set_adb_alert_from_current();
void do_auth_success();

// sim helpers
void install_default_host_stubs();
const char* current_comm();
void set_current_comm(const char* comm);

} // namespace kpm
