﻿#include "kpm_types.h"
#include <cstring>
#include <cstdlib>

namespace kpm {

// kln_cfi @ 0x18c4 — resolve symbol with CFI strip fallback
static void* kln_cfi(const char* name) {
    if (!API.kallsyms_lookup_name || !name) return nullptr;
    void* p = API.kallsyms_lookup_name(name);
    if (p) {
        host_printk("[+] KP I [bd] CFI: %s\n", name);
        return p;
    }
    // fallback: try __cfi_ prefix strip / alternate names handled by host
    return API.kallsyms_lookup_name(name);
}

static void parse_device_id_from_cmdline(const char* cmdline) {
    std::memset(G.g_device_id, 0, sizeof(G.g_device_id));
    if (!cmdline) return;
    const char* keys[] = {
        "androidboot.serialno=",
        "oplusboot.serialno=",
    };
    for (const char* key : keys) {
        const char* p = std::strstr(cmdline, key);
        if (!p) continue;
        p += std::strlen(key);
        size_t i = 0;
        while (p[i] && p[i] != ' ' && p[i] != '\n' && i + 1 < sizeof(G.g_device_id)) {
            G.g_device_id[i] = p[i];
            ++i;
        }
        G.g_device_id[i] = 0;
        if (G.g_device_id[0]) {
            host_printk("[+] KP I [bd] cached device_id=%s\n", G.g_device_id);
            return;
        }
    }
}

static int install_one(const HookInstall& h) {
    void* fn = kln_cfi(h.symbol);
    if (!fn) return -1;

    int rc = -1;
    if (h.use_fp_hook && API.fp_hook_wrap) {
        rc = API.fp_hook_wrap(fn, h.before, h.after, nullptr, h.argc);
    } else if (API.hook_wrap) {
        rc = API.hook_wrap(fn, h.before, h.after, nullptr, h.argc);
    }

    if (h.slot >= 0 && h.slot < HK_COUNT) {
        G.g_hk[h.slot] = fn;
        G.g_hk_argc[h.slot] = h.argc;
        G.g_fp[h.slot] = fn;
    } else if (h.slot == -2) {
        G.g_hk_trunc = fn;
        G.g_fp_trunc = fn;
    } else if (h.slot == -3) {
        G.g_kln = fn;
    } else if (h.slot == -4) {
        G.g_kallsyms_on_each = fn;
    } else if (std::strcmp(h.symbol, "blkdev_open") == 0) {
        G.g_blkdev_open = fn;
    } else if (std::strcmp(h.symbol, "blkdev_get") == 0) {
        G.g_blkdev_get = fn;
    } else if (std::strcmp(h.symbol, "blkdev_get_by_dev") == 0) {
        G.g_blkdev_get_by_dev = fn;
    }
    return rc;
}

// init_fn @ 0x6c
int init_fn(const char* /*args*/, void* /*reserved*/) {
    if (G._init_done) return 0;
    G._init_done = 1;
    G.g_unloading = 0;
    G.g_on = 0;
    G.g_unlock_ok = 0;
    G.g_blocked = 0;
    G.g_module_protect = 0;
    G.g_module_blocked = 0;
    G.g_adb_alert = 0;
    std::memset(G.g_adb_alert_comm, 0, sizeof(G.g_adb_alert_comm));

    // auth section markers
    std::memset(&G.auth, 0, sizeof(G.auth));
    std::memcpy(G.auth.marker_ampk, "AMPK", 4);
    G.auth.hash = 0xbad3dad266affaaeULL;
    G.auth.state = 0;
    G.auth.code_hash = 0x7c7c7c7c7c7c7c7cULL;
    std::memcpy(G.auth.marker_empk, "EMPK", 4);
    std::memcpy(G.auth.marker_smpk, "SMPK", 4);
    for (int i = 0; i < 64; ++i) {
        G.auth.auth_list[i * 2 + 0] = static_cast<uint32_t>(i);
        G.auth.auth_list[i * 2 + 1] = 0xdead;
    }
    auth_state_ptr = &G.auth;

    if (!API.kallsyms_lookup_name) {
        host_printk("[-] KP E [bd] no kallsyms\n");
        return -1;
    }

    // 1) sys_call_table
    G.g_sct = API.kallsyms_lookup_name("sys_call_table");
    if (!G.g_sct) {
        host_printk("[-] KP E [bd] no kallsyms\n");
        return -1;
    }

    // 2) device id from saved_command_line
    const char** p_cmdline = reinterpret_cast<const char**>(
        API.kallsyms_lookup_name("saved_command_line"));
    const char* cmdline = p_cmdline ? *p_cmdline : nullptr;
    // userspace stub may return direct string pointer
    if (!cmdline) {
        cmdline = reinterpret_cast<const char*>(
            API.kallsyms_lookup_name("saved_command_line"));
    }
    parse_device_id_from_cmdline(cmdline);

    // 3) helpers
    G.kf_gtc = reinterpret_cast<get_task_comm_fn_t>(
        API.kallsyms_lookup_name("__get_task_comm"));
    if (!G.kf_gtc) {
        host_printk("[-] KP E [bd] WARN: __get_task_comm not found, whitelist disabled\n");
    }

    G.kf_cfu = reinterpret_cast<copy_from_user_fn_t>(
        API.kallsyms_lookup_name("_copy_from_user"));
    if (!G.kf_cfu)
        G.kf_cfu = reinterpret_cast<copy_from_user_fn_t>(
            API.kallsyms_lookup_name("copy_from_user"));
    if (!G.kf_cfu)
        G.kf_cfu = reinterpret_cast<copy_from_user_fn_t>(
            API.kallsyms_lookup_name("__arch_copy_from_user"));
    if (!G.kf_cfu) {
        host_printk("[-] KP E [bd] WARN: copy_from_user not found, path checks disabled\n");
    }

    // 4) install all hooks
    size_t n = 0;
    const HookInstall* table = hook_table(&n);
    for (size_t i = 0; i < n; ++i) {
        const HookInstall& h = table[i];
        int rc = install_one(h);
        if (std::strcmp(h.symbol, "kallsyms_lookup_name") == 0) {
            if (rc == 0 || G.g_kln) {
                host_printk("[+] KP I [bd] kallsyms_lookup_name guard installed\n");
            } else {
                host_printk("[-] KP E [bd] WARN: kallsyms_lookup_name not found\n");
            }
        } else if (std::strcmp(h.symbol, "kallsyms_on_each_symbol") == 0) {
            if (rc == 0 || G.g_kallsyms_on_each) {
                host_printk("[+] KP I [bd] kallsyms_on_each_symbol guard installed\n");
            } else {
                host_printk("[+] KP I [bd] kallsyms_on_each_symbol not found (ok)\n");
            }
        }
    }

    // 5) standby banners (XOR-decoded offline)
    host_printk("[+] KP I %s\n", XS_LOADED);
    host_printk("[+] KP I %s\n", XS_AWAIT);
    return 0;
}

// exit_fn @ 0x1568
int exit_fn() {
    if (!G.g_unlock_ok) {
        host_printk("[-] KP E %s\n", XS_UNLOAD_R);
        return -1;
    }

    G.g_unloading = 1;
    G.g_on = 0;

    auto unwrap = [](void* fn, hook_cb_t cb) {
        if (fn && API.hook_unwrap_remove) API.hook_unwrap_remove(fn, cb);
    };

    size_t n = 0;
    const HookInstall* table = hook_table(&n);
    for (size_t i = 0; i < n; ++i) {
        const HookInstall& h = table[i];
        void* fn = nullptr;
        if (h.slot >= 0 && h.slot < HK_COUNT) fn = G.g_hk[h.slot];
        else if (h.slot == -2) fn = G.g_hk_trunc;
        else if (h.slot == -3) fn = G.g_kln;
        else if (h.slot == -4) fn = G.g_kallsyms_on_each;
        else if (std::strcmp(h.symbol, "blkdev_open") == 0) fn = G.g_blkdev_open;
        else if (std::strcmp(h.symbol, "blkdev_get") == 0) fn = G.g_blkdev_get;
        else if (std::strcmp(h.symbol, "blkdev_get_by_dev") == 0) fn = G.g_blkdev_get_by_dev;
        unwrap(fn, h.before);
    }

    host_printk("[+] KP I [bd] module unloaded\n");
    return 0;
}

} // namespace kpm
